using System.ComponentModel;
using System.Diagnostics;
using DynaDocs.Services.Statechart;

try
{
    return args[0] switch
    {
        "error" => NativeError(int.Parse(args[1])),
        "owner" => await Owner(args[1]),
        "cli" => await Cli(),
        "worker" => await Worker(),
        "leaf" => await Leaf(),
        "observer" => await Observer(args[1]),
        _ => throw new ArgumentException("Unknown native fixture role.")
    };
}
catch (InvalidDataException error)
{
    Console.Error.WriteLine(error.Message);
    return 2;
}

static Process Start(string role, params string[] arguments)
{
    var start = new ProcessStartInfo(Environment.ProcessPath!)
    {
        UseShellExecute = false,
        CreateNoWindow = true,
        RedirectStandardInput = true,
        RedirectStandardOutput = true,
        RedirectStandardError = false
    };
    start.ArgumentList.Add(role);
    foreach (var argument in arguments) start.ArgumentList.Add(argument);
    return Process.Start(start) ?? throw new InvalidOperationException("Fixture child did not start.");
}

static async Task Say(string value)
{
    await Console.Out.WriteLineAsync(value);
    await Console.Out.FlushAsync();
}

static int NativeError(int pid)
{
    using var job = new WindowsStatechartJob();
    try
    {
        job.Attach(pid);
        return 3;
    }
    catch (Win32Exception error)
    {
        Console.WriteLine(error.NativeErrorCode);
        return 0;
    }
}

static async Task<int> Owner(string receipt)
{
    using var job = new WindowsStatechartJob();
    using var observer = Start("observer", receipt);
    await observer.StandardInput.WriteLineAsync(job.DuplicateCompletionPortTo(observer).ToString());
    await observer.StandardInput.FlushAsync();
    if (await observer.StandardOutput.ReadLineAsync() != "observer-ready")
        throw new InvalidDataException("Independent observer did not become ready.");
    using var cli = Start("cli");
    var gate = new StatechartProtocol();
    gate.AcceptReady(await cli.StandardOutput.ReadLineAsync());
    await Say($"gated {Environment.ProcessId} {observer.Id} {cli.Id}");
    if (await Console.In.ReadLineAsync() != "attach") return 2;
    job.Attach(cli.Id);
    gate.ConfirmOwnership();
    await Say($"owned {job.Contains(cli.Id)} {job.Contains(observer.Id)}");
    if (await Console.In.ReadLineAsync() != "register") return 2;
    // The fixture acknowledges the gate only; it does not claim production directory registration.
    gate.ConfirmScratchRegistration();
    await Say("registered");
    if (await Console.In.ReadLineAsync() != "go") return 2;
    await gate.ReleaseAsync(cli.StandardInput);
    await Say(await cli.StandardOutput.ReadLineAsync() ?? "missing-tree");
    if (await Console.In.ReadLineAsync() != "terminate") return 2;
    job.Terminate();
    await Say("terminated");
    if (await Console.In.ReadLineAsync() != "count") return 2;
    await Say($"active {job.ActiveProcesses()}");
    observer.StandardInput.Close();
    await observer.WaitForExitAsync();
    return 0;
}

static async Task<int> Cli()
{
    await StatechartProtocol.WaitForGoAsync(Console.In, Console.Out);
    using var worker = Start("worker");
    var gate = new StatechartProtocol();
    gate.AcceptReady(await worker.StandardOutput.ReadLineAsync());
    gate.ConfirmOwnership();
    gate.ConfirmScratchRegistration();
    await gate.ReleaseAsync(worker.StandardInput);
    await Say($"tree {Environment.ProcessId} {await worker.StandardOutput.ReadLineAsync()}");
    await Console.In.ReadToEndAsync();
    return 2;
}

static async Task<int> Worker()
{
    await StatechartProtocol.WaitForGoAsync(Console.In, Console.Out);
    using var leaf = Start("leaf");
    if (await leaf.StandardOutput.ReadLineAsync() != "leaf-ready")
        throw new InvalidDataException("Descendant did not become ready.");
    await Say($"{Environment.ProcessId} {leaf.Id}");
    await Console.In.ReadToEndAsync();
    return 2;
}

static async Task<int> Leaf()
{
    await Say("leaf-ready");
    await Console.In.ReadToEndAsync();
    return 2;
}

static async Task<int> Observer(string receipt)
{
    var raw = await Console.In.ReadLineAsync();
    if (!nint.TryParse(raw, out var handle)) return 2;
    using var completion = new WindowsStatechartCompletion(handle);
    await Say("observer-ready");
    await Console.In.ReadToEndAsync();
    var empty = completion.WaitForEmpty(TimeSpan.FromSeconds(3));
    // Notification is an observation, never permission to delete directories in this feasibility fixture.
    await File.WriteAllTextAsync(receipt, empty ? "empty-observed\n" : "ambiguous-retained\n");
    return empty ? 0 : 2;
}
